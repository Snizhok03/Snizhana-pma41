from enum import Enum


class TodoItemVisibilityEnum(Enum):
    VISIBLE = "visible"
    ARCHIVED = "archived"
