from pydantic import BaseModel


class BaseAPIModel(BaseModel):
    pass
